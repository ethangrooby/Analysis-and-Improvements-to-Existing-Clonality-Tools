%reconstruct.m
%Author: Ethan Grooby
%Created: 27/08/2017
%obtains all the CNV and SNV clonalites and errors for all the samples and
%clonalSNV and clonalCNV are the locations of where the germline locations
%are
function [SNV, CNV, clonalSNV, clonalCNV] = reconstruct(file,locationSNV, locationCNV)
clone=locate(file,'clone');
sizefile=size(file);
column=sizefile(2)-clone;
SNVrow=numel(locationSNV);
CNVrow=numel(locationCNV);
SNV=zeros(SNVrow,column);
CNV=zeros(CNVrow,column);
for i=1:SNVrow
    SNV(i,:)=cell2mat(file(locationSNV(i),(clone+1):sizefile(2)));

    if strcmp(cell2mat(file(locationSNV(i),clone)),'germline')
        clonalSNV=i;
    end
end
for i=1:CNVrow
    CNV(i,:)=cell2mat(file(locationCNV(i),(clone+1):sizefile(2)));
    if strcmp(cell2mat(file(locationCNV(i),clone)),'germline')
        clonalCNV=i;
    end
end
end 



