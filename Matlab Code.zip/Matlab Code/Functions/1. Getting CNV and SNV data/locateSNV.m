%locateSNV.m
%Author: Ethan Grooby
%Created: 27/08/2017
%function goes through the file to find the location of the SNVs and CNVs
%And CNV size filter
function [locationSNV, locationCNV] = locateSNV(file,CNVsizecutoff)
start=locate(file,'start');
finish=locate(file,'end');
a=size(file);
row=a(1);
locationSNV=[];
locationCNV=[];
for i=2:row
    length=cell2mat(file(i,finish))-cell2mat(file(i,start));
    if length==0
        locationSNV=[locationSNV i];
    elseif length>=CNVsizecutoff 
        locationCNV=[locationCNV i];
    end 
end 
end
        
        