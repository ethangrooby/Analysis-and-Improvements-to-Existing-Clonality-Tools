%locate.m
%Author: Ethan Grooby
%Created: 27/08/2017
%this function finds the column location of a specific parameter
function [ location ] = locate(file,string)
%location= column location
%file=data you want to search through
%string= in '' what you want to search
a=size(file);
filec=a(2);
for i=1:filec
    if strcmp(char(file(1,i)),string)
        location=i;
        return 
    end 
end
location=0;

end

