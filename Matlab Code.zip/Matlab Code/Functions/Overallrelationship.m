function [similaritycomposition,similaritypercentagecaptured,complete,relationship,overallSNVerror, overallCNVerror,Y,Y2,T11,Z11,T12,Z12,T21,Z21,T22,Z22,CNV, SNV, extraSNV, extraCNV, cluster,cluster1, SNVrelate,clonesinfo,removedextraCNV,removedCNV,clonesinfoCNV,groupsSNV,groupsCNV] = Overallrelationship(file,CNVerrorcutoff, cutoff,maxdistance)
%%%%%%%%%%%%%%%%%%%%%%%%%%%
if maxdistance==-1
    [a, b]=size(file);
    s=(b-5)/2;
    load t
    if s>30
        d=t(31);
    else
        d=t(s);
    end
    maxdistance=sqrt(s*d^s);
end
if CNVerrorcutoff==-1
    CNVerrorcutoff=1;
end
if cutoff==-1
    cutoff=1;
end
fullZmaxdist=5000;
CNVsizecutoff=10000;
remove=1;
maxinput=0.05;
%%%%%%%%%%%%%%%%%%%%%%%%%%%
[locationSNV, locationCNV] = locateSNV(file,CNVsizecutoff);
[SNV, CNV, clonalSNV, clonalCNV]=reconstruct(file,locationSNV, locationCNV);
[CNV,extraCNV,locationCNV,removedlocationCNV, removedextraCNV,removedCNV] = CNVfilter(file,CNV,clonalCNV,remove,CNVerrorcutoff,locationCNV);
[SNVrelate,cluster,locationSNV,extraSNV] = SNVrelationship2(file,SNV,clonalSNV,locationSNV, remove, maxinput,cutoff);
getlost=1;
[cluster1,T11,Z11,SNV,removedSNV,extraSNV,removedextraSNV,Y] = SNVcluster(SNV,SNVrelate,cluster,cutoff,maxdistance,clonalSNV,getlost,extraSNV,fullZmaxdist);
[clonesinfo]=extractinfo(T11,cluster);
[Y2,T21,Z21] = CNVcluster(CNV,maxdistance,extraCNV,fullZmaxdist);
[clonesinfoCNV]=extractinfoCNV(T21,CNV,extraCNV);
[samples]=overallgroupwithouterror(file,clonesinfo,clonesinfoCNV);
[clonesinfo,T12,Z12,groupsSNV]=SNVhigherror(clonesinfo,removedSNV,maxdistance,removedextraSNV,fullZmaxdist,extraSNV);
[clonesinfoCNV,T22,Z22,groupsCNV]=CNVhigherror(clonesinfoCNV,removedCNV,maxdistance,removedextraCNV,fullZmaxdist,extraCNV);
[overallSNVerror, overallCNVerror,samples]=overallgroup(file,clonesinfo,clonesinfoCNV,groupsCNV,groupsSNV);
[complete,relationship]=subclone(overallSNVerror,overallCNVerror,maxdistance);
[similarity,similaritycomposition,similaritypercentagecaptured]=comparison(file,complete);
end 
