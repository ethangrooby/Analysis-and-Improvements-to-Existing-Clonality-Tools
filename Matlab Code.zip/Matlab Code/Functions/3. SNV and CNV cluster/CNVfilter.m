function [CNV,extraCNV,locationCNV,removedlocationCNV, removedextraCNV,removedCNV] = CNVfilter(file,CNV,clonalCNV,remove,CNVerrorcutoff,locationCNV)
%CNV- CNV clonalities and error 
%extraCNV- extra CNV data from the filtered CNVs
%locationCNV- need location of CNVs that have been filtered from germline
%and errorcutoff 
%removedlocationCNV-location of the CNVs removed due to high errors
%removedCNV- clonalities and error 
%removedextraCNV- the extra information on them 


[row, column]=size(CNV);
CNV2=[];
removedCNV=[];
locationCNV2=[];
removedlocationCNV=[];
clustererror=CNV(:,column/2+1:end);
for k=CNVerrorcutoff:0.05:1
    temp=clustererror>=0.5*k;
    temp2=zeros(row,1);
    for i=1:row
        temp2(i)=sum(temp(i,:));
    end
    temp=temp2>0;
    perror=sum(temp)/row;
    if perror<0.5
        break
    end
end
CNVerrorcutoff=k;

for i=1:row
    if (remove==1)&&(i<(clonalCNV+1))
        continue 
    else
        for j=1:(column/2)
            getrid=0;
            if CNV(i,j+column/2)>=CNVerrorcutoff
                getrid=1;
                removedlocationCNV=[removedlocationCNV,locationCNV(i)];
                removedCNV=[removedCNV;CNV(i,:)];
                break
            end
        end
        if getrid==1
            continue
        else
            CNV2=[CNV2;CNV(i,:)];
            locationCNV2=[locationCNV2, locationCNV(i)];
        end
    end
end 
CNV=CNV2;
start=locate(file,'start');
finish=locate(file,'end');
name=locate(file,'name');
locationCNV=locationCNV2;
[CNVrow, CNVcolumn]=size(locationCNV);
extraCNV=cell(CNVcolumn,3);
for i=1:CNVcolumn
    extraCNV{i,1}=file{locationCNV(i),start};
    extraCNV{i,2}=file{locationCNV(i),finish};
    extraCNV{i,3}=file{locationCNV(i),name};
end

[CNVrow, CNVcolumn]=size(removedlocationCNV);
removedextraCNV=cell(CNVcolumn,3);
for i=1:CNVcolumn
    removedextraCNV{i,1}=file{removedlocationCNV(i),start};
    removedextraCNV{i,2}=file{removedlocationCNV(i),finish};
    removedextraCNV{i,3}=file{removedlocationCNV(i),name};
end



end
