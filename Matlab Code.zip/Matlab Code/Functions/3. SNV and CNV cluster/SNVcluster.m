function [cluster1,T,Z,SNV,removedSNV,extraSNV,removedextraSNV,Y] = SNVcluster(SNV,SNVrelate,cluster1,cutoff,maxdistance,clonalSNV,getlost,extraSNV,fullZmaxdist)
%cutoff=standard deviation cutoff so that we can contain 95% of the info in
%the data of 0.5*cutoff
[crow, ccolumn]=size(cluster1);
removedSNV=[];
SNV2=[];
removedextraSNV=[];
extraSNV2=[];
clustererror=cluster1{1,2};
[row, col]=size(clustererror);

for k=cutoff:0.05:1
    temp=clustererror>=0.5*k;
    temp2=zeros(row,1);
    for i=1:row
        temp2(i)=sum(temp(i,:));
    end
    temp=temp2>0;
    perror=sum(temp)/row;
    if perror<0.5
        break
    end
end
cutoff=k;

for i=1:row
    getrid=0;
    for j=1:col
        if clustererror(i,j)>=0.5*cutoff
            removedSNV=[removedSNV;SNV(clonalSNV+i,:)];
            removedextraSNV=[removedextraSNV;extraSNV(i,:)];
            getrid=1;
            break
        end
    end
    if getrid==0;
        SNV2=[SNV2;SNV(i+clonalSNV,:)];
        extraSNV2=[extraSNV2;extraSNV(i,:)];
    end    
end 
SNV=SNV2;        
extraSNV=extraSNV2;

[row ,column]=size(SNV);
clones=column/2;
cluster1=cell(1,2,1);
cluster1{:,1}=SNV(:,1:clones);
cluster1{:,2}=SNV(:,(clones+1):column);
for i=1:crow 
    a=cluster1{i,1};
    [row col]=size(a);
    Y=mydistance(cluster1{i,1},cluster1{i,2},ones(1,row));
    %need to redefine distance to mydistance
    if numel(Y)==0
        keyboard
        continue
    else
        if fullZmaxdist==0
            [Z,m]=mylinkage(Y,cluster1{i,1},cluster1{i,2},ones(1,row),maxdistance);
        %need to view Z and stop when the clustering size increase is
        %significantly different 
        else
            [Z,m]=mylinkage(Y,cluster1{i,1},cluster1{i,2},ones(1,row),fullZmaxdist);
        end
        T = mycluster(Z,maxdistance);
    end
end
cluster1=Z;
end



            
            
    

