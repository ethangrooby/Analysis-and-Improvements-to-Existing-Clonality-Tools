function [q]=probability2(mu,sigma)
y= @(x,sigma,mu) (sigma*(2*pi)^0.5)^(-1)*x.^2.*exp(-(x-mu).^2/(2*sigma^2));
q=integral(@(x)y(x,sigma,mu),-inf,inf);
end