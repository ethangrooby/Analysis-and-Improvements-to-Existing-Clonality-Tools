function [Z,m]=mylinkage(distance,cluster,cluster2,w,maxdistance)
if numel(distance)==0
    Z=zeros(1,3);
    m=0;
    return
end
[totalelements,b]=size(cluster);
relationship=1:totalelements;
mean=cluster;
[m, samples]=size(mean);
Z=zeros((numel(mean)/samples-1),3);
sd=cluster2;
for j=1:((numel(mean)/samples)-1)
    elements=numel(distance);
    low=min(distance);
    if low>maxdistance
        break
    end
    location=find(distance==low);
    tempdist=zeros(1,numel(distance));
    tempdist(location(1))=1;
    [nrow,ncol,v]=find(squareform(tempdist)==1);
    temp=sort(nrow);
    nrow=temp(1);
    ncol=temp(2);
    Z(j,:)=[relationship(nrow), relationship(ncol), low];
    newmean=zeros(1,samples);
    newsd=zeros(1,samples);
    for k=1:samples
        mean1=mean(nrow,k);
        mean2=mean(ncol,k);
        sd1=sd(nrow,k);
        sd2=sd(ncol,k);
        w1=w(nrow);
        w2=w(ncol);
        newmean(k)=(w1*mean1+w2*mean2)/(w1+w2);
        Ex=(w1*probability2(mean1,sd1)+w2*probability2(mean2,sd2))/(w1+w2);
        newsd(k)=sqrt(Ex-newmean(k)^2);
        neww=w1+w2;
    end
    mean(nrow,:)=[];
    mean((ncol-1),:)=[];
    w(nrow)=[];
    w((ncol-1))=[];
    sd(nrow,:)=[];
    sd((ncol-1),:)=[];
    mean=[mean; newmean];
    w=[w, neww];
    sd=[sd; newsd];
    relationship2=zeros(1,numel(mean)/samples);
    relationship2(numel(mean)/samples)=totalelements+1;
    back=0;
    for i=1:numel(relationship)
        if i==nrow
            back=1;
        elseif i==ncol
            back=2;
        else
            relationship2(i-back)=relationship(i);
        end
    end
    relationship=relationship2;
    totalelements=totalelements+1;
    distance=mydistance(mean,sd,w);
end

end

   


