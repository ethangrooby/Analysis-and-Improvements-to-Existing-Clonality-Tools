function [clonesinfo]=extractinfo(T,cluster)
cluster1=cluster{1,1,1};
[row,col]=size(cluster1);
cluster2=cluster{1,2,1};
clonesinfo=cell(max(T),4,1);
for i=1:max(T)
    clonesinfo{i,2,1}=zeros(1,col);
    clonesinfo{i,3,1}=zeros(1,col);
end
for i=1:numel(T)
    clonesinfo{T(i),1,1}=[clonesinfo{T(i),1,1}, i];
    w1=numel(clonesinfo{T(i),1,1})-1;
    if w1==0
        clonesinfo{T(i),2,1}=cluster1(i,:);
        clonesinfo{T(i),3,1}=cluster2(i,:);
        clonesinfo{T(i),4,1}=1;
        continue
    end 
    w2=1;
    mu=clonesinfo{T(i),2,1};
    sigma=clonesinfo{T(i),3,1};
    for k=1:col
        mean1=mu(k);
        mean2=cluster1(i,k);
        sd1=sigma(k);
        sd2=cluster2(i,k);
        mu(k)=(w1*mean1+w2*mean2)/(w1+w2);
        newmean=mu(k);
        Ex=(w1*probability2(mean1,sd1)+w2*probability2(mean2,sd2))/(w1+w2);
        sigma(k)=sqrt(Ex-newmean^2);
    end
    clonesinfo{T(i),2,1}=mu;
    clonesinfo{T(i),3,1}=sigma;
    clonesinfo{T(i),4,1}=numel(clonesinfo{T(i),1,1}); 
end
end 
