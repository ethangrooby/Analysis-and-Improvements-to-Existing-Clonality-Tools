function [distance]=mydistance(cluster,cluster2,w)
[row, column]=size(cluster);
dimension=(row^2-row)/2;
distance=zeros(1,dimension);
counter=0;
for i=1:row
    for j=(i+1):row
        dist=0;
        n1=w(i);
        n2=w(j);
        for k=1:column
            a=cluster(i,k)-cluster(j,k);
            b=sqrt(cluster2(i,k)^2/n1+cluster2(j,k)^2/n2);
            dist=dist+(((a/b)^2)^0.5)^column;
        end
        dist=dist^0.5;
        counter=counter+1;
        distance(counter)=dist;
    end
end
end

        
        
            
            
        