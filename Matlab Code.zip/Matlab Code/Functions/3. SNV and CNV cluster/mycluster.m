function T = mycluster(Z,maxdistance)
[a,b]=size(Z);
T=zeros(a+1,1);
Temp=cell(2*a+1,1);
for i=1:a+1;
    Temp{i,1}=i;
end
for i=1:a
    if Z(i,3)>maxdistance||Z(i,1)==0
        break
    end
    Temp{i+a+1,1}=[Temp{Z(i,1)},Temp{Z(i,2)}];
    Temp{Z(i,1)}=[];
    Temp{Z(i,2)}=[];
end
Temp = Temp(~cellfun('isempty', Temp'));
[a,b]=size(Temp);
for i=1:a
    clones=Temp{i,1};
    for j=1:numel(clones)
        T(clones(j))=i;
    end
end
end
