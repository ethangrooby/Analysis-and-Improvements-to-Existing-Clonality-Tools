%clustering of CNV
function [Y,T2,Z2] = CNVcluster(CNV,maxdistance,extraCNV,fullZmaxdist)
%T2- what clone each mutation goes into 
%Z2- order of clustering- can use dendrogram to visualize the clustering 

%fullZmaxdist- to allow to get the full Z2 matrix to use dendrogram
%function 

[row, col]=size(CNV);
cluster1=CNV(:,1:(col/2));
cluster2=CNV(:,(col/2+1):col);
w=zeros(1,row);
for i=1:row
    a=extraCNV{i,2};
    b=extraCNV{i,1};
    w(i)=a-b;
end
average=sum(w)/numel(w);   %%%%%%%%%%%%%%%%%change to bin size
w=w/average;
Y=mydistance(cluster1,cluster2,w);
if fullZmaxdist==0
    [Z2,m]=mylinkage(Y,cluster1,cluster2,w,maxdistance);
else
    [Z2,m]=mylinkage(Y,cluster1,cluster2,w,fullZmaxdist);
end 
T2 = mycluster(Z2,maxdistance);
end



