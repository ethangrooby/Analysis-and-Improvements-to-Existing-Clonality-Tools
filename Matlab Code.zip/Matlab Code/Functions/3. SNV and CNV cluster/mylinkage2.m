function [Z,m]=mylinkage2(distance,cluster,cluster2,w,maxdistance,notcluster,notcluster2)
totalelements=notcluster2;
relationship=1:totalelements;
mean=cluster;
[m, samples]=size(mean);
Z=zeros(notcluster2-1,3);
sd=cluster2;
for j=1:((numel(mean)/samples)-1)
    elements=numel(distance);
    organized=sort(distance);
    for k=1:numel(organized)
        done=0;
        low=organized(k);    
        if low>maxdistance
            return
        end
        location=find(distance==low);
        tempdist=zeros(1,numel(distance));
        tempdist(location(1))=1;
        [nrow,ncol,v]=find(squareform(tempdist)==1);
        temp=sort(nrow);
        nrow=temp(1);
        ncol=temp(2);
        if (notcluster<relationship(nrow))&&(relationship(nrow)<=notcluster2)&& (notcluster<relationship(ncol))&&(relationship(ncol)<=notcluster2)
        elseif (relationship(nrow)<=notcluster)&&(relationship(ncol)>notcluster2)
        elseif (relationship(nrow)<=notcluster)&& (relationship(ncol)<=notcluster)
        elseif (relationship(nrow)>notcluster2)&&(relationship(ncol)>notcluster2)
        else
            done=1;
            break
        end
    end
    if done==0
        return
    end
    Z(j,:)=[relationship(nrow), relationship(ncol), low];
    newmean=zeros(1,samples);
    newsd=zeros(1,samples);
    for k=1:samples
        mean1=mean(nrow,k);
        mean2=mean(ncol,k);
        sd1=sd(nrow,k);
        sd2=sd(ncol,k);
        w1=w(nrow);
        w2=w(ncol);
        newmean(k)=(w1*mean1+w2*mean2)/(w1+w2);
        Ex=(w1*probability2(mean1,sd1)+w2*probability2(mean2,sd2))/(w1+w2);
        newsd(k)=sqrt(Ex-newmean(k)^2);
        neww=w1+w2;
    end
    mean(nrow,:)=[];
    mean((ncol-1),:)=[];
    w(nrow)=[];
    w((ncol-1))=[];
    sd(nrow,:)=[];
    sd((ncol-1),:)=[];
    mean=[mean; newmean];
    w=[w, neww];
    sd=[sd; newsd];
    relationship2=zeros(1,numel(mean)/samples);
    relationship2(numel(mean)/samples)=totalelements+1;
    back=0;
    for i=1:numel(relationship)
        if i==nrow
            back=1;
        elseif i==ncol
            back=2;
        else
            relationship2(i-back)=relationship(i);
        end
    end
    relationship=relationship2;
    totalelements=totalelements+1;
    distance=mydistance(mean,sd,w);
end
end