function [clonesinfoCNV,T2,Z2,groupsCNV]=CNVhigherror(clonesinfoCNV,removedCNV,maxdistance,removedextraCNV,fullZmaxdist,extraCNV)
clonesinfo_original=clonesinfoCNV;
[a,b,c]=size(clonesinfoCNV);
[d,b]=size(clonesinfoCNV{1,2,1});
A=zeros(a,2*b);
for i=1:a;
    A(i,:)=[clonesinfoCNV{i,2,1},clonesinfoCNV{i,3,1}];
end 
removedCNV2=[A;removedCNV];


[row, col]=size(removedCNV2);
row2=a;

cluster1=removedCNV2(:,1:(col/2));
cluster2=removedCNV2(:,(col/2+1):col);
w=zeros(1,row);


for i=1:row2
    w(i)=clonesinfoCNV{i,4,1};
end


for i=(row2+1):row
    a=removedextraCNV{i-row2,2};
    b=removedextraCNV{i-row2,1};
    w(i)=a-b;
end


average=sum(w)/numel(w);
w=w/average;
Y=mydistance(cluster1,cluster2,w);
if fullZmaxdist==0
    [Z2,m]=mylinkage2(Y,cluster1,cluster2,w,maxdistance,row2,row);
else
    [Z2,m]=mylinkage2(Y,cluster1,cluster2,w,fullZmaxdist,row2,row);
end 
if numel(Z2)==0||Z2(1)==0;
    T2=1:row;
    T2=T2';
else 
    T2 = mycluster(Z2,maxdistance);
end
[row, col]=size(removedCNV2);
cluster1=removedCNV2(:,1:(col/2));
cluster2=removedCNV2(:,(col/2+1):col);
[row,col]=size(cluster1);
clonesinfoCNV=cell(max(T2),4,1);
for i=1:max(T2)
    clonesinfoCNV{i,2,1}=zeros(1,col);
    clonesinfoCNV{i,3,1}=zeros(1,col);
    clonesinfoCNV{i,4,1}=0;
end

w=w*average;
for i=1:numel(T2)
    clonesinfoCNV{T2(i),1,1}=[clonesinfoCNV{T2(i),1,1}, i];
    w1=clonesinfoCNV{T2(i),4,1};
    if w1==0
        clonesinfoCNV{T2(i),2,1}=cluster1(i,:);
        clonesinfoCNV{T2(i),3,1}=cluster2(i,:);
        clonesinfoCNV{T2(i),4,1}=w(i);
        continue
    end 
    w2=w(i);
    mu=clonesinfoCNV{T2(i),2,1};
    sigma=clonesinfoCNV{T2(i),3,1};
    for k=1:col
        mean1=mu(k);
        mean2=cluster1(i,k);
        sd1=sigma(k);
        sd2=cluster2(i,k);
        mu(k)=(w1*mean1+w2*mean2)/(w1+w2);
        newmean=mu(k);
        Ex=(w1*probability2(mean1,sd1)+w2*probability2(mean2,sd2))/(w1+w2);
        sigma(k)=sqrt(Ex-newmean^2);
        clonesinfoCNV{T2(i),4,1}=w1+w2;
    end
    clonesinfoCNV{T2(i),2,1}=mu;
    clonesinfoCNV{T2(i),3,1}=sigma;
end


[a, b, c]=size(clonesinfoCNV);
groupsCNV=cell(a,3,1);
for i=1:a
    clones=clonesinfoCNV{i,1,1};
    for j=1:numel(clones)
        if clones(j)<=row2
            c1=clonesinfo_original{clones(j),1,1};
            for k=1:numel(c1)
                groupsCNV{i,1,1}=[groupsCNV{i,1,1};extraCNV{c1(k),1,1}];
                groupsCNV{i,2,1}=[groupsCNV{i,2,1};extraCNV{c1(k),2,1}];
                groupsCNV{i,3,1}=[groupsCNV{i,3,1};extraCNV(c1(k),3,1)];
            end
        else
            groupsCNV{i,1,1}=[groupsCNV{i,1,1};removedextraCNV{(clones(j)-row2),1,1}];
            groupsCNV{i,2,1}=[groupsCNV{i,2,1};removedextraCNV{(clones(j)-row2),2,1}];
            groupsCNV{i,3,1}=[groupsCNV{i,3,1};removedextraCNV((clones(j)-row2),3,1)];
        end
    end 
end 





end





