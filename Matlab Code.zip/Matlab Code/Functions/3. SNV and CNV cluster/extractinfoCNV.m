function [clonesinfoCNV]=extractinfoCNV(T,CNV,extraCNV)
%clonesinfo- organized into clones
%          - the new calculated means and standard deviations for the
%          clones
%1= locations of clones  2= mean 3= standard deviations 
w=zeros(1,numel(T));
for i=1:numel(w)
    a=extraCNV{i,1};
    b=extraCNV{i,2};
    w(i)=w(i)+b-a;
end

[row, col]=size(CNV);
cluster1=CNV(:,1:(col/2));
cluster2=CNV(:,(col/2+1):col);
[row,col]=size(cluster1);
clonesinfoCNV=cell(max(T),4,1);
for i=1:max(T)
    clonesinfoCNV{i,2,1}=zeros(1,col);
    clonesinfoCNV{i,3,1}=zeros(1,col);
    clonesinfoCNV{i,4,1}=0;
end
for i=1:numel(T)
    clonesinfoCNV{T(i),1,1}=[clonesinfoCNV{T(i),1,1}, i];
    w1=clonesinfoCNV{T(i),4,1};
    if w1==0
        clonesinfoCNV{T(i),2,1}=cluster1(i,:);
        clonesinfoCNV{T(i),3,1}=cluster2(i,:);
        clonesinfoCNV{T(i),4,1}=w(i);
        continue
    end 
    w2=w(i);
    mu=clonesinfoCNV{T(i),2,1};
    sigma=clonesinfoCNV{T(i),3,1};
    for k=1:col
        mean1=mu(k);
        mean2=cluster1(i,k);
        sd1=sigma(k);
        sd2=cluster2(i,k);
        mu(k)=(w1*mean1+w2*mean2)/(w1+w2);
        newmean=mu(k);
        Ex=(w1*probability2(mean1,sd1)+w2*probability2(mean2,sd2))/(w1+w2);
        sigma(k)=sqrt(Ex-newmean^2);
        clonesinfoCNV{T(i),4,1}=w1+w2;
    end
    clonesinfoCNV{T(i),2,1}=mu;
    clonesinfoCNV{T(i),3,1}=sigma;
end
end 
