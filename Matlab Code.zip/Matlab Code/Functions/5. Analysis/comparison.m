function [similarity,similaritycomposition,similaritypercentagecaptured]=comparison(file,complete)
clone=locate(file,'clone');
start=locate(file,'start');
finish=locate(file,'end');
fstart=cell2mat(file(3:end,start));
fend=cell2mat(file(3:end,finish));
fclone=file(3:end,clone);
for i=1:numel(fstart)
    if strcmp(cell2mat(fclone(i)),'germline')
        fclone{i}=-1;
    end
end
fclone=cell2mat(fclone);
[row,col]=size(complete);
similarity=cell(row,2);
for i=1:row
    sloc=complete{i,1};
    if numel(sloc)==0
    else 
        similar=zeros(numel(sloc),1);
        for j=1:numel(sloc)
            a=find(fstart==sloc(j));
            b=find(fend==sloc(j));
            if numel(intersect(a,b))==1
                similar(j)=fclone(intersect(a,b));
            else
                [C,ia,ib] = intersect(a,b);
                done=0;
                for k=1:numel(ia)
                    if ia(k)==ib(k)
                        similar(j)=fclone(C(k));
                        done=1;
                        break
                    end
                end
                if done==0;
                    similar(j)=fclone(C(1));
                end
            end
        end
        similarity{i,1}=similar;
    end
end
for i=1:row
    cstart=complete{i,5};
    cend=complete{i,6};
    if numel(cstart)==0
    else 
        similar=zeros(numel(cstart),1);
        for j=1:numel(cstart)
            a=find(fstart==cstart(j));
            b=find(fend==cend(j));
            if numel(intersect(a,b))==1
                similar(j)=fclone(intersect(a,b));
            else 
                [C,ia,ib] = intersect(a,b);
                done=0;
                for k=1:numel(ia)
                    if ia(k)==ib(k)
                        similar(j)=fclone(C(k));
                        done=1;
                        break
                    end
                end
                if done==0;
                    similar(j)=fclone(C(1));
                end
            end
                        
        end
        similarity{i,2}=similar;
    end
end

sfclone=fclone(end);
similaritycomposition=zeros(row,sfclone);
for i=1:row
    for k=1:2
        if numel(similarity{i,k})==0
            continue
        end
        for j=1:sfclone
            similaritycomposition(i,j)=similaritycomposition(i,j)+numel(find(similarity{i,k}==j))/(numel(similarity{i,1})+numel(similarity{i,2}));
        end
    end
end
similaritycomposition( ~any(similaritycomposition,2), : ) = [];


similaritypercentagecaptured=zeros(row,sfclone);
for i=1:row
    for k=1:2
        if numel(similarity{i,k})==0
            continue
        end
        for j=1:sfclone
            similaritypercentagecaptured(i,j)=similaritypercentagecaptured(i,j)+numel(find(similarity{i,k}==j))/numel(find(fclone==j));
        end
    end
end
similaritypercentagecaptured( ~any(similaritypercentagecaptured,2), : ) = [];

end


