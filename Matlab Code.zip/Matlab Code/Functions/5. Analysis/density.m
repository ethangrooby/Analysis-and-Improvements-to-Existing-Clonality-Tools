function density(Z,decimal)
Z=Z(:,3);
Z=round(Z,decimal);
Z=sort(Z);
d=[Z(1),1];
j=1;
for i=2:numel(Z)
    if Z(i)==d(j,1)
        d(j,2)=d(j,2)+1;
    else
        d=[d;Z(i),1];
        j=j+1;
    end
end
x=d(:,1)';
y=d(:,2)';
semilogx(x,y)
axis([0 max(x) 0 max(y)])
hold 
x=12.65*ones(numel(y));
semilogx(x,y)
xlabel('Distance')
ylabel('Density')
title('Distance vs Density')
end

    