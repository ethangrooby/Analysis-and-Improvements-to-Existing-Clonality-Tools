function density2(Y,decimal)
Y=round(Y,decimal);
Y=sort(Y);
d=[Y(1),1];
j=1;
for i=2:numel(Y)
    if Y(i)==d(j,1)
        d(j,2)=d(j,2)+1;
    else
        d=[d;Y(i),1];
        j=j+1;
    end
end
x=d(:,1)';
y=d(:,2)';
semilogx(x,y)
axis([0 max(x) 0 max(y)])
hold 
x=9.09*ones(2);
y=[0 max(y)];
semilogx(x,y)
xlabel('Distance')
ylabel('Density')
title('Distance vs Density')
end