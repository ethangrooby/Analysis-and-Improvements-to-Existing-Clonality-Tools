function [SNVrelate,cluster,locationSNV,extraSNV] = SNVrelationship(file,SNV,clonalSNV,locationSNV, remove, maxinput,cutoff)
%remove=1 means remove the germline SNVs that are provided in clonalSNV
%locationSNV- new locations given removal of germline
%cluster is SNV data with removal of high error data
%extraSNV is the extra information of the SNVs located in SNV cluster
%SNVrelate is the SNV binary
[row ,column]=size(SNV);
clones=column/2;
SNV2=SNV;
SNV=SNV(:,1:clones);
totalcombos=0;
for i=2:clones
    totalcombos=nchoosek(clones,i)+totalcombos;
end
SNVrelate=zeros(totalcombos,clones+2);
%All Combinations of Clones Taken i at a Time
%https://au.mathworks.com/help/matlab/ref/nchoosek.html
cluster=cell(totalcombos,2,1);
totalcombos=0;
for i=2:clones
    combos=nchoosek(clones,i);
    sectionend=combos+totalcombos;
    SNVrelate((totalcombos+1):sectionend,1)=i*ones((sectionend-totalcombos),1);
    SNVrelate((totalcombos+1):sectionend,2:(i+1))=nchoosek(1:clones,i);
    totalcombos=sectionend;
end 
locationSNV2=[];
for i=1:row
    if (remove==1)&&(i<(clonalSNV+1))
        continue
    end
    locationSNV2=[locationSNV2, locationSNV(i)];
    temp=zeros(1,clones);
    temp2=[];
    temp3=[];
    nonzero=0;
    for j=1:clones
        if (SNV(i,j)~=0)&&(round(probability(SNV(i,j),SNV2(i,j+clones),maxinput),3)<cutoff)
            nonzero=nonzero+1;
            temp(nonzero)=j;
            temp2=[temp2,j];
            temp3=[temp3,j+clones]; 
        end
    end
    for k=1:totalcombos
        if temp==SNVrelate(k,2:clones+1)
            SNVrelate(k,clones+2)=SNVrelate(k,clones+2)+1;
            cluster{k,1}=[cluster{k,1};SNV2(i,temp2)];
            cluster{k,2}=[cluster{k,2};SNV2(i,temp3)];
            %cluster=order is clonality, error, clonality, error 
        end
    end
end
SNVrelate2=SNVrelate(:,clones+2)>0;
SNVrelate=SNVrelate(SNVrelate2,:);
cluster=cluster(SNVrelate2,:,:);
locationSNV=locationSNV2;
start=locate(file,'start');
name=locate(file,'name');
[SNVrow, SNVcolumn]=size(locationSNV);
extraSNV=cell(SNVcolumn,2);
for i=1:SNVcolumn
    extraSNV{i,1}=file{locationSNV(i),start};
    extraSNV{i,2}=file{locationSNV(i),name};
end
end




