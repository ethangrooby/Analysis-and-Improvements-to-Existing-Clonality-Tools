function [SNVrelate,cluster,locationSNV,extraSNV] = SNVrelationship2(file,SNV,clonalSNV,locationSNV, remove, maxinput,cutoff)
%remove=1 means remove the germline SNVs that are provided in clonalSNV
%locationSNV- new locations given removal of germline
%cluster is SNV data with removal of high error data
%extraSNV is the extra information of the SNVs located in SNV cluster
%SNVrelate is the SNV binary
%redefined SNVrelate SNV binary- is defined as the odds of a particular
%combination of samples being related

[row ,column]=size(SNV);
clones=column/2;
SNV2=SNV;
SNV=SNV(:,1:clones);
totalcombos=0;
cluster=cell(1,2,1);
cluster{:,1}=SNV((clonalSNV+1):row,:);
cluster{:,2}=SNV2((clonalSNV+1):row,(clones+1):column);
for i=2:clones
    totalcombos=nchoosek(clones,i)+totalcombos;
end
SNVrelate=zeros(totalcombos,clones+2);
%All Combinations of Clones Taken i at a Time
%https://au.mathworks.com/help/matlab/ref/nchoosek.html

totalcombos=0;
for i=2:clones
    combos=nchoosek(clones,i);
    sectionend=combos+totalcombos;
    SNVrelate((totalcombos+1):sectionend,1)=i*ones((sectionend-totalcombos),1);
    SNVrelate((totalcombos+1):sectionend,2:(i+1))=nchoosek(1:clones,i);
    totalcombos=sectionend;
end 
locationSNV2=[];
for i=1:row
    if (remove==1)&&(i<(clonalSNV+1))
        continue
    end
    locationSNV2=[locationSNV2, locationSNV(i)];
    [row, column]=size(SNVrelate);
    for j=1:row
        q=1;
        for k=2:(SNVrelate(j,1)+1)
            mu=SNV(i,SNVrelate(j,k));
            sigma=SNV2(i,(SNVrelate(j,k)+clones));
            if mu==0
                %q=q*probability3(mu,sigma,maxinput);
            else
                %q=q*probability3(mu,sigma,0);
            end
        end
        %q=1-q;
        if SNVrelate(j,column)==0
            SNVrelate(j,column)=1;
        end
        SNVrelate(j,column)=SNVrelate(j,column)*q;
    end   
end
for i=1:row
    SNVrelate(i,column)=1-SNVrelate(i,column);
end
locationSNV=locationSNV2;
start=locate(file,'start');
name=locate(file,'name');
[SNVrow, SNVcolumn]=size(locationSNV);
extraSNV=cell(SNVcolumn,2);
for i=1:SNVcolumn
    extraSNV{i,1}=file{locationSNV(i),start};
    extraSNV{i,2}=file{locationSNV(i),name};
end
end