function [q]=probability(mu,sigma,maxinput)
%used in SNVrelationship
y= @(x,sigma,mu) (sigma*(2*pi)^0.5)^(-1)*exp(-(x-mu).^2/(2*sigma^2));
q=integral(@(x)y(x,sigma,mu),-inf,maxinput);
end
