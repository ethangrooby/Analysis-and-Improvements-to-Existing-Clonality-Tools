function [q]=probability3(mu,sigma,maxinput)
%used in SNVrelationship2
y= @(x,sigma,mu) (sigma*(2*pi)^0.5)^(-1)*exp(-(x-mu).^2/(2*sigma^2));
q=integral(@(x)y(x,sigma,mu),maxinput,inf);
end
