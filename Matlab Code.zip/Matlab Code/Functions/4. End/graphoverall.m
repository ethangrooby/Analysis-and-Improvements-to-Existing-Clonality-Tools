%graphoverall
a=locate(file,'clone');
[b,c]=size(file);
start=a+1;
sam=(c-a)/2;
samples=cell(1,sam);
for i=start:start+sam
    temp=char(file{1,i});
    loc=find(temp=='.');
    samples{i-start+1}=mat2str(temp(loc(1)+1:end));
end


a=size(overallCNV{1,1});
x=1:a;
b=3;
[row,col]=size(overallCNV);
for i=1:row
    a=size(overallCNV{i,1});
    if a<2
        continue
    end 
    y=overallCNV{i,b+1};
    err=overallCNV{i,b+2};
    x=1:numel(y);
    figure
    errorbar(x,y,err);
    set(gca,'xtick',1:x,'xticklabel',samples);
    title(sprintf('CNV Clone %0.0f size %0.0f',i,a(1)));
end

b=2;
[row,col]=size(overallSNV);
for i=1:row
    a=size(overallSNV{i,1});
    if a<2
        continue
    end 
    y=overallSNV{i,b+1};
    err=overallSNV{i,b+2};
    x=1:numel(y);
    figure
    errorbar(x,y,err);
    set(gca,'xtick',1:x,'xticklabel',samples);
    title(sprintf('SNV Clone %0.0f size %0.0f',i,a(1)));
end
