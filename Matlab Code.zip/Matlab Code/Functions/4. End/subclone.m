function [complete,relationship]=subclone(overallSNVerror,overallCNVerror,maxdistance)
[srow,scol]=size(overallSNVerror);
sloc=[];
for i=1:srow
    if numel(overallSNVerror{i,1})>1
        sloc=[sloc,i];
    end
end
overallSNVerror2=cell(numel(sloc),scol);
for i=1:numel(sloc)
    for j=1:scol
        overallSNVerror2(i,j)=overallSNVerror(sloc(i),j);
    end
end
[crow,ccol]=size(overallCNVerror);
cloc=[];
for i=1:crow
    if numel(overallCNVerror{i,1})>1
        cloc=[cloc,i];
    end
end
overallCNVerror2=cell(numel(cloc),ccol);
for i=1:numel(cloc)
    for j=1:ccol
        overallCNVerror2(i,j)=overallCNVerror(cloc(i),j);
    end
end
complete=cell(numel(cloc)+numel(sloc),ccol+scol);
complete(1:numel(sloc),1:scol)=overallSNVerror2;
for i=1:numel(cloc)
    best=10000;
    mean1=overallCNVerror2{i,4};
    error1=overallCNVerror2{i,5};
    %n1=numel(overallCNVerror2{i,3});
    n1=1;
    for j=1:numel(sloc)
        mean2=overallSNVerror2{j,3};
        error2=overallSNVerror2{j,4};
        %n2=numel(overallCNVerror2{i,2});
        n2=1;
        dist=0;
        for k=1:numel(mean1)
            a=mean1(k)-mean2(k);
            b=sqrt(error1(k)^2/n1+error2(k)^2/n2);
            dist=dist+(((a/b)^2)^0.5)^numel(mean1);
        end
        dist=dist^0.5;  
        if dist<best
            best=dist;
            bestloc=j;
        end
    end
    if best<maxdistance
        complete(j,scol+1:end)=overallCNVerror2(i,:);
    else 
        complete(i+numel(sloc),scol+1:end)=overallCNVerror2(i,:);
    end
end
complete(all(cellfun('isempty',complete),2),:) = [];  
[rowc,colc]=size(complete);
relationship=cell(rowc,rowc);
for i=1:rowc
    for j=1:rowc
        if i==j
            relationship{i,j}=sprintf('-');
            continue
        end
        mean1=complete{i,3};
        mean2=complete{j,3};
        ratio=zeros(1,numel(mean1));
        done=0;
        for k=1:numel(mean1)
            if mean1(k)+mean2(k)>1
                if mean1(k)>mean2(k)
                    relationship{i,j}=sprintf('%d subclone %d',j,i);
                else
                    relationship{i,j}=sprintf('%d subclone %d',i,j);
                end
                done=1;
                break
            end
            ratio(k)=mean1(k)/mean2(k);
        end
        if done==0
            if sum(ratio>=1)==numel(ratio)
                relationship{i,j}=sprintf('%d subclone %d',j,i);
            elseif sum(ratio<=1)==numel(ratio)
                relationship{i,j}=sprintf('%d subclone %d',i,j);
            else 
                relationship{i,j}='independent'; 
            end
        end    
    end
end
end
     




