function [overallSNV, overallCNV,samples]=overallgroup(file,clonesinfo,clonesinfoCNV,groupsCNV,groupsSNV)
a=locate(file,'clone');
[b,c]=size(file);
start=a+1;
sam=(c-a)/2;
samples=cell(1,sam);
for i=start:start+sam-1
    temp=char(file{1,i});
    loc=find(temp=='.');
    samples{i-start+1}=mat2str(temp(loc(1)+1:end));
end
[a, b]=size(groupsSNV);
overallSNV=cell(a,b+2);
for i=1:a
    for j=1:b
        overallSNV{i,j}=groupsSNV{i,j};
    end
    for j=1:2
        overallSNV{i,j+b}=clonesinfo{i,j+1};
    end
end

[a, b]=size(groupsCNV);
overallCNV=cell(a,b+2);
for i=1:a
    for j=1:b
        overallCNV{i,j}=groupsCNV{i,j};
    end
    for j=1:2
        overallCNV{i,j+b}=clonesinfoCNV{i,j+1};
    end
end

x=1:sam;

[row,col]=size(overallCNV);
figure
names=cell(row,1);
for i=1:row
    a=size(overallCNV{i,1});
    if a<2
        continue
    end 
    y=overallCNV{i,b+1};
    err=overallCNV{i,b+2};
    hold on
    errorbar(x,y,err);
    set(gca,'xtick',1:sam,'xticklabel',samples);
    names{i,1}=sprintf('CNV Clone %0.0f size %0.0f',i,a(1));
end
names=names(~cellfun('isempty',names));
legend(names)
title('CNV')
[a, b]=size(groupsSNV);
[row,col]=size(overallSNV);
figure
names=cell(row,1);
for i=1:row
    a=size(overallSNV{i,1});
    if a<2
        continue
    end 
    y=overallSNV{i,b+1};
    hold on
    err=overallSNV{i,b+2};
    errorbar(x,y,err);
    set(gca,'xtick',1:sam,'xticklabel',samples);
    names{i,1}=sprintf('SNV Clone %0.0f size %0.0f',i,a(1));
end
names=names(~cellfun('isempty',names));
legend(names)
title('SNV')



    