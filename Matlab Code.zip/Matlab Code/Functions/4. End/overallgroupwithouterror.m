function [samples]=overallgroupwithouterror(file,clonesinfo,clonesinfoCNV)
a=locate(file,'clone');
[b,c]=size(file);
start=a+1;
sam=(c-a)/2;
samples=cell(1,sam);
for i=start:start+sam-1
    temp=char(file{1,i});
    loc=find(temp=='.');
    samples{i-start+1}=mat2str(temp(loc(1)+1:end));
end
x=1:sam;

[row,col]=size(clonesinfoCNV);
figure
names=cell(row,1);
for i=1:row
    a=numel(clonesinfoCNV{i,1});
    if a<2
        continue
    end 
    y=clonesinfoCNV{i,2};
    err=clonesinfoCNV{i,3};
    hold on
    errorbar(x,y,err);
    set(gca,'xtick',1:sam,'xticklabel',samples);
    names{i,1}=sprintf('CNV Clone %0.0f size %0.0f',i,a(1));
end
names=names(~cellfun('isempty',names));
legend(names)
title('CNV without error')

[row,col]=size(clonesinfo);
figure
names=cell(row,1);
for i=1:row
    a=numel(clonesinfo{i,1});
    if a<2
        continue
    end 
    y=clonesinfo{i,2};
    hold on
    err=clonesinfo{i,3};
    errorbar(x,y,err);
    set(gca,'xtick',1:sam,'xticklabel',samples);
    names{i,1}=sprintf('SNV Clone %0.0f size %0.0f',i,a(1));
end
names=names(~cellfun('isempty',names));
legend(names)
title('SNV without error')

